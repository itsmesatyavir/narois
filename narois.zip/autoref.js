const { main } = require("./ref/src");

main().catch((err) => console.error(err));
